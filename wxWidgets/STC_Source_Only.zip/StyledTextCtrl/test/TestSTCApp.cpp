/***************************************************************
 * Name:      TestSTCApp.cpp
 * Purpose:   Code for Application Class
 * Author:     ()
 * Created:   2010-03-14
 * Copyright:  ()
 * License:
 **************************************************************/

#include "TestSTCApp.h"

//(*AppHeaders
#include "TestSTCMain.h"
#include <wx/image.h>
//*)

IMPLEMENT_APP(TestSTCApp);

bool TestSTCApp::OnInit()
{
    //(*AppInitialize
    bool wxsOK = true;
    wxInitAllImageHandlers();
    if ( wxsOK )
    {
    	TestSTCFrame* Frame = new TestSTCFrame(0);
    	Frame->Show();
    	SetTopWindow(Frame);
    }
    //*)
    return wxsOK;

}
