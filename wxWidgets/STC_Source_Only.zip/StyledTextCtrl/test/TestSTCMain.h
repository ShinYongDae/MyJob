/***************************************************************
 * Name:      TestSTCMain.h
 * Purpose:   Defines Application Frame
 * Author:     ()
 * Created:   2010-03-14
 * Copyright:  ()
 * License:
 **************************************************************/

#ifndef TESTSTCMAIN_H
#define TESTSTCMAIN_H

//(*Headers(TestSTCFrame)
#include <wx/notebook.h>
#include <wx/sizer.h>
#include <wx/menu.h>
#include "stedit.h"
#include "wxscintilla.h"
#include <wx/panel.h>
#include <wx/richtext/richtextctrl.h>
#include <wx/frame.h>
//*)

class TestSTCFrame: public wxFrame
{
    public:

        TestSTCFrame(wxWindow* parent,wxWindowID id = -1);
        virtual ~TestSTCFrame();

    private:

        //(*Handlers(TestSTCFrame)
        void OnQuit(wxCommandEvent& event);
        void OnAbout(wxCommandEvent& event);
        //*)

        //(*Identifiers(TestSTCFrame)
        static const long ID_STC1;
        static const long ID_PANEL1;
        static const long ID_RTF1;
        static const long ID_PANEL2;
        static const long ID_STE1;
        static const long ID_PANEL3;
        static const long ID_NOTEBOOK1;
        static const long idMenuQuit;
        static const long idMenuAbout;
        //*)

        //(*Declarations(TestSTCFrame)
        wxNotebook* Notebook1;
        wxScintilla* STC1;
        wxSTEditor* STE1;
        wxPanel* Panel1;
        wxPanel* Panel3;
        wxRichTextCtrl* RTF1;
        wxPanel* Panel2;
        //*)

        DECLARE_EVENT_TABLE()
};

#endif // TESTSTCMAIN_H
