/***************************************************************
 * Name:      TestSTCApp.h
 * Purpose:   Defines Application Class
 * Author:     ()
 * Created:   2010-03-14
 * Copyright:  ()
 * License:
 **************************************************************/

#ifndef TESTSTCAPP_H
#define TESTSTCAPP_H

#include <wx/app.h>

class TestSTCApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // TESTSTCAPP_H
