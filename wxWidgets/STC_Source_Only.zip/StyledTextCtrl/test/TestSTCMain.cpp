/***************************************************************
 * Name:      TestSTCMain.cpp
 * Purpose:   Code for Application Frame
 * Author:     ()
 * Created:   2010-03-14
 * Copyright:  ()
 * License:
 **************************************************************/

#include "TestSTCMain.h"
#include <wx/msgdlg.h>

//(*InternalHeaders(TestSTCFrame)
#include <wx/font.h>
#include <wx/intl.h>
#include <wx/string.h>
//*)

//helper functions
enum wxbuildinfoformat {
    short_f, long_f };

wxString wxbuildinfo(wxbuildinfoformat format)
{
    wxString wxbuild(wxVERSION_STRING);

    if (format == long_f )
    {
#if defined(__WXMSW__)
        wxbuild << _T("-Windows");
#elif defined(__UNIX__)
        wxbuild << _T("-Linux");
#endif

#if wxUSE_UNICODE
        wxbuild << _T("-Unicode build");
#else
        wxbuild << _T("-ANSI build");
#endif // wxUSE_UNICODE
    }

    return wxbuild;
}

//(*IdInit(TestSTCFrame)
const long TestSTCFrame::ID_STC1 = wxNewId();
const long TestSTCFrame::ID_PANEL1 = wxNewId();
const long TestSTCFrame::ID_RTF1 = wxNewId();
const long TestSTCFrame::ID_PANEL2 = wxNewId();
const long TestSTCFrame::ID_STE1 = wxNewId();
const long TestSTCFrame::ID_PANEL3 = wxNewId();
const long TestSTCFrame::ID_NOTEBOOK1 = wxNewId();
const long TestSTCFrame::idMenuQuit = wxNewId();
const long TestSTCFrame::idMenuAbout = wxNewId();
//*)

BEGIN_EVENT_TABLE(TestSTCFrame,wxFrame)
    //(*EventTable(TestSTCFrame)
    //*)
END_EVENT_TABLE()

TestSTCFrame::TestSTCFrame(wxWindow* parent,wxWindowID id)
{
wxControl   *ctl;

    //(*Initialize(TestSTCFrame)
    wxBoxSizer* BoxSizer4;
    wxMenuItem* MenuItem2;
    wxMenuItem* MenuItem1;
    wxBoxSizer* BoxSizer2;
    wxMenu* Menu1;
    wxBoxSizer* BoxSizer1;
    wxMenuBar* MenuBar1;
    wxBoxSizer* BoxSizer3;
    wxMenu* Menu2;

    Create(parent, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxDEFAULT_FRAME_STYLE, _T("wxID_ANY"));
    SetClientSize(wxSize(800,600));
    BoxSizer1 = new wxBoxSizer(wxHORIZONTAL);
    Notebook1 = new wxNotebook(this, ID_NOTEBOOK1, wxDefaultPosition, wxSize(801,434), 0, _T("ID_NOTEBOOK1"));
    Panel1 = new wxPanel(Notebook1, ID_PANEL1, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL, _T("ID_PANEL1"));
    BoxSizer2 = new wxBoxSizer(wxHORIZONTAL);
    STC1 = new wxScintilla(Panel1, ID_STC1, wxDefaultPosition, wxSize(128, 128), wxRAISED_BORDER|wxWANTS_CHARS, _T("ID_STC1"));
    wxFont STC1Font(10,wxSWISS,wxFONTSTYLE_NORMAL,wxNORMAL,false,_T("Courier New"),wxFONTENCODING_DEFAULT);
    STC1->SetFont(STC1Font);
    STC1->StyleSetFont(wxSCI_STYLE_DEFAULT, STC1Font);
    STC1->StyleSetFont(0, STC1Font);
    STC1->SetCaretStyle(1);
    STC1->SetCaretPeriod(500);
    STC1->SetCaretWidth(2);
    STC1->SetSelectionMode(0);
    STC1->SetMargins(0, 0);
    STC1->SetMarginWidth(1, 20);
    STC1->SetMarginType(1, 1);
    STC1->SetMarginWidth(2, 0);
    STC1->SetMarginType(2, 0);
    STC1->SetMarginWidth(3, 0);
    STC1->SetMarginType(3, 0);
    STC1->SetViewWhiteSpace(0);
    STC1->SetEOLMode(2);
    STC1->SetTabWidth(8);
    STC1->StyleSetCase(wxSCI_STYLE_DEFAULT, 0);
    STC1->StyleSetCase(0, 0);
    STC1->SetIndent(0);
    STC1->SetBackSpaceUnIndents(true);
    STC1->SetWrapMode(0);
    STC1->SetWrapIndentMode(0);
    STC1->SetBufferedDraw(true);
    STC1->SetZoom(0);
    STC1->AppendText(_("Code::Blocks is a free C++ IDE built to meet the most demanding needs of its users. It is designed to be very extensible and fully configurable.\n"));
    STC1->AppendText(_("\n"));
    STC1->AppendText(_("Finally, an IDE with all the features you need, having a consistent look, feel and operation across platforms.\n"));
    STC1->AppendText(_("\n"));
    STC1->AppendText(_("Built around a plugin framework, Code::Blocks can be extended with plugins. Any kind of functionality can be added by installing/coding a plugin. For instance, compiling and debugging functionality is already provided by plugins!\n"));
    STC1->AppendText(_("\n"));
    STC1->AppendText(_("We hope you enjoy using Code::Blocks!\n"));
    STC1->AppendText(_("\n"));
    STC1->AppendText(_("The Code::Blocks Team\n"));
    STC1->SetOvertype(false);
    STC1->SetReadOnly(false);
    BoxSizer2->Add(STC1, 1, wxALL|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    Panel1->SetSizer(BoxSizer2);
    BoxSizer2->Fit(Panel1);
    BoxSizer2->SetSizeHints(Panel1);
    Panel2 = new wxPanel(Notebook1, ID_PANEL2, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL, _T("ID_PANEL2"));
    BoxSizer3 = new wxBoxSizer(wxHORIZONTAL);
    RTF1 = new wxRichTextCtrl(Panel2, ID_RTF1, wxEmptyString, wxDefaultPosition, wxSize(32, 32), wxRE_MULTILINE|wxRAISED_BORDER|wxWANTS_CHARS|wxVSCROLL|wxHSCROLL|wxALWAYS_SHOW_SB, wxDefaultValidator, _T("ID_RTF1"));
    wxFont RTF1Font(10,wxSWISS,wxFONTSTYLE_NORMAL,wxNORMAL,false,_T("Courier New"),wxFONTENCODING_DEFAULT);
    RTF1->SetFont(RTF1Font);
    RTF1->SetVirtualSize(wxSize(2000,2000))RTF1->AppendText(_("Code::Blocks is a free C++ IDE built to meet the most demanding needs of its users. It is designed to be very extensible and fully configurable.\n"));
    RTF1->AppendText(_("\n"));
    RTF1->AppendText(_("Finally, an IDE with all the features you need, having a consistent look, feel and operation across platforms.\n"));
    RTF1->AppendText(_("\n"));
    RTF1->AppendText(_("Built around a plugin framework, Code::Blocks can be extended with plugins. Any kind of functionality can be added by installing/coding a plugin. For instance, compiling and debugging functionality is already provided by plugins!\n"));
    RTF1->AppendText(_("\n"));
    RTF1->AppendText(_("We hope you enjoy using Code::Blocks!\n"));
    RTF1->AppendText(_("\n"));
    RTF1->AppendText(_("The Code::Blocks Team\n"));
    BoxSizer3->Add(RTF1, 1, wxALL|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    Panel2->SetSizer(BoxSizer3);
    BoxSizer3->Fit(Panel2);
    BoxSizer3->SetSizeHints(Panel2);
    Panel3 = new wxPanel(Notebook1, ID_PANEL3, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL, _T("ID_PANEL3"));
    BoxSizer4 = new wxBoxSizer(wxHORIZONTAL);
    STE1 = new wxSTEditor(Panel3, ID_STE1, wxDefaultPosition, wxSize(32, 32), wxRAISED_BORDER|wxWANTS_CHARS, _T("ID_STE1"));
    wxFont STE1Font(10,wxSWISS,wxFONTSTYLE_NORMAL,wxNORMAL,false,_T("Courier New"),wxFONTENCODING_DEFAULT);
    STE1->SetFont(STE1Font);
    STE1->AppendText(_("Code::Blocks is a free C++ IDE built to meet the most demanding needs of its users. It is designed to be very extensible and fully configurable.\n"));
    STE1->AppendText(_("\n"));
    STE1->AppendText(_("Finally, an IDE with all the features you need, having a consistent look, feel and operation across platforms.\n"));
    STE1->AppendText(_("\n"));
    STE1->AppendText(_("Built around a plugin framework, Code::Blocks can be extended with plugins. Any kind of functionality can be added by installing/coding a plugin. For instance, compiling and debugging functionality is already provided by plugins!\n"));
    STE1->AppendText(_("\n"));
    STE1->AppendText(_("We hope you enjoy using Code::Blocks!\n"));
    STE1->AppendText(_("\n"));
    STE1->AppendText(_("The Code::Blocks Team\n"));
    BoxSizer4->Add(STE1, 1, wxALL|wxEXPAND|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    Panel3->SetSizer(BoxSizer4);
    BoxSizer4->Fit(Panel3);
    BoxSizer4->SetSizeHints(Panel3);
    Notebook1->AddPage(Panel1, _("Scintilla"), false);
    Notebook1->AddPage(Panel2, _("Rich Text"), false);
    Notebook1->AddPage(Panel3, _("Styled Text Editor"), false);
    BoxSizer1->Add(Notebook1, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    SetSizer(BoxSizer1);
    MenuBar1 = new wxMenuBar();
    Menu1 = new wxMenu();
    MenuItem1 = new wxMenuItem(Menu1, idMenuQuit, _("Quit\tAlt-F4"), _("Quit the application"), wxITEM_NORMAL);
    Menu1->Append(MenuItem1);
    MenuBar1->Append(Menu1, _("&File"));
    Menu2 = new wxMenu();
    MenuItem2 = new wxMenuItem(Menu2, idMenuAbout, _("About\tF1"), _("Show info about this application"), wxITEM_NORMAL);
    Menu2->Append(MenuItem2);
    MenuBar1->Append(Menu2, _("Help"));
    SetMenuBar(MenuBar1);
    BoxSizer1->SetSizeHints(this);

    Connect(idMenuQuit,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&TestSTCFrame::OnQuit);
    Connect(idMenuAbout,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&TestSTCFrame::OnAbout);
    //*)

RTF1->SetVirtualSize(2000, 2000);
RTF1->SetupScrollbars();


}

TestSTCFrame::~TestSTCFrame()
{
    //(*Destroy(TestSTCFrame)
    //*)
}

void TestSTCFrame::OnQuit(wxCommandEvent& event)
{
    Close();
}

void TestSTCFrame::OnAbout(wxCommandEvent& event)
{
    wxString msg = wxbuildinfo(long_f);
    wxMessageBox(msg, _("Welcome to..."));
}
