this directory and files is only here to keep the Code::Blocks SDK happy
while compiling the components

it is not used for anything else
