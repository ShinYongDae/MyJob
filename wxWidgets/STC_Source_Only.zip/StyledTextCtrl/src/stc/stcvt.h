#ifndef  __stcvt_h__
#define  __stcvt_h__

// peskly little conversion routines

//------------------------------------------------------------------------------
#if wxUSE_UNICODE
#include "UniConversion.h"

// Convert using Scintilla's functions instead of wx's, Scintilla's are more
// forgiving and won't assert...

static wxString stc2wx(const char* str, size_t len)
{
    if (!len)
        return wxEmptyString;

    size_t wclen = UTF16Length(str, len);
    wxWCharBuffer buffer(wclen+1);

    size_t actualLen = UTF16FromUTF8(str, len, buffer.data(), wclen+1);
    return wxString(buffer.data(), actualLen);
}



static wxString stc2wx(const char* str)
{
    return stc2wx(str, strlen(str));
}


static const wxWX2MBbuf wx2stc(const wxString& str)
{
    const wchar_t* wcstr = str.c_str();
    size_t wclen         = str.length();
    size_t len           = UTF8Length(wcstr, wclen);

    wxCharBuffer buffer(len+1);
    UTF8FromUTF16(wcstr, wclen, buffer.data(), len);

    // TODO check NULL termination!!

    return buffer;
}

//------------------------------------------------------------------------------
#else // not UNICODE

static  wxString stc2wx(const char* str) {
    return wxString(str);
}
static  wxString stc2wx(const char* str, size_t len) {
    return wxString(str, len);
}
static  const wxWX2MBbuf wx2stc(const wxString& str) {
    return str.mbc_str();
}

#endif // UNICODE


#endif


