del /S /Q .cvsignore
