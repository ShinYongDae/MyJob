/*
* This file is part of a wxSmith plugin for Code::Blocks Studio
* Copyright (C) 2007  Bartlomiej Swiecki
*
* wxSmith is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* wxSmith and this file is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with wxSmith; if not, write to the Free Software
* Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
* 
* Ron Collins
* rcoll@theriver.com
* 26-Feb-2010
* 
*/



=============
wxSmithSTC
=============

-------------------
General Description
-------------------

wxSmithSTC is a plugin for Code::Blocks and wxSmith that provides styled text
control widgets to the GUI designer.

Specifically, the components wxScintilla, wxRichTextCtrl, and wxSTEditor are
now available on the component tab list of wxSmith (tab "Styled Text).

This plug-in provides these components for visual design, and exposes most of
the properties and attributes for initial setup; however, it does not (as yet)
provide ancillary components (such as style sheets or text attributes, except
those used for the default fonts and colors). 


The wxSmithSTC build directory has the following structure:
StyledTextCtrl\
    bin\                // this dir contains the binary file output of the 
                        // Code::Blocks projects; files include "TestSTC.exe",
                        // "wxsSmithSTC.dll",  and "wxsSmithSTC.zip"
    images\             // a set of usefull XPM images for buttons (empty)         
    include\            // the include file "wxSmithSTC.h" is here
    lib\                // the library "wxSmithSTC.a" is here
    obj\                // intermediate files for all compiles
    project\            // this is the Code::Bocks project to create the
                        // wxSmithSTC library; it creates the file
                        // "wxSmithSTC.a" and places the library file and
                        // the include file in the proper directories 
    src\                // source files for component wxSmithSTC
    test\               // this is the Code::Blocks project to create a test
                        // program for wxSmithSTC; the output file
                        // "TestSTC.exe" is placed in the ..\bin\ directory
        wxsmith\        // used by Code::Blocks and wxSmith
    wxs\                // this is the Code::Blocks project to create the
                        // plugin for Code::Blocks and wxSmith, to put the
                        // component wxSmithSTC on the wxSmith palette.
                        // the output files "wxsSmithPlot.dll" and
                        // and "wxsSmithPlot.zip" are placed in the ..\bin\
                        // directory; they must be manually copied to the
                        // plugin directory of your Code::Blocks installation.
        images\         // images used on the wxSmith palette 
        src\            // source code for the property pages used by
                        // wxSmith for the wxSmithSTC component

The Code::Blocks projects used here were created and tested under Windows XP,
using Code::Blocks SVN version 5866, and wxWidgets version 2.8.  The correct 
order to build these projects is:

1) Build the library (project found in the "project\" directory)
2) Build the wxSmith plugin (project found in the "wxs\" directory)
3) Exit Code::Blocks and install the plugins
   copy "bin\wxsSmithSTC.dll" to "<Code::Blocks>\share\CodeBlocks\plugins"
   copy "bin\wxsSmithSTC.zip" to "<Code::Blocks>\share\CodeBlocks"
4) Re-start Code::Blocks and build the test program (project found in the
   "test\" directory)

(For Windows XP, all of these projects and programs are already compiled; you
only need to install the plugin files into your own Code::Blocks installation
directory).


 