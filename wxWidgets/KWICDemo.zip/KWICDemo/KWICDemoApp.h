/***************************************************************
 * Name:      KWICDemoApp.h
 * Purpose:   Defines Application Class
 * Author:    Gary Harris (garyjharris@sourceforge.net)
 * Created:   2010-04-22
 * Copyright: Gary Harris (http://cryogen.66ghz.com/)
 * License:	KWIC Licence
 **************************************************************/

#ifndef KWICDEMOAPP_H
#define KWICDEMOAPP_H

#include <wx/app.h>

class KWICDemoApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // KWICDEMOAPP_H
