/***************************************************************
 * Name:      TestdcMain.cpp
 * Purpose:   Code for Application Frame
 * Author:    Gary Harris (garyjharris@sourceforge.net)
 * Created:   2010-04-22
 * Copyright: Gary Harris (http://cryogen.66ghz.com/)
 * License:	KWIC Licence
 **************************************************************/

#include "wx_pch.h"
#include "TestdcMain.h"
#include <wx/msgdlg.h>

//(*InternalHeaders(TestdcFrame)
#include <wx/bitmap.h>
#include <wx/font.h>
#include <wx/intl.h>
#include <wx/image.h>
#include <wx/string.h>
//*)

//helper functions
enum wxbuildinfoformat {
    short_f, long_f };

wxString wxbuildinfo(wxbuildinfoformat format)
{
    wxString wxbuild(wxVERSION_STRING);

    if (format == long_f )
    {
#if defined(__WXMSW__)
        wxbuild << _T("-Windows");
#elif defined(__UNIX__)
        wxbuild << _T("-Linux");
#endif

#if wxUSE_UNICODE
        wxbuild << _T("-Unicode build");
#else
        wxbuild << _T("-ANSI build");
#endif // wxUSE_UNICODE
    }

    return wxbuild;
}

//(*IdInit(TestdcFrame)
const long TestdcFrame::ID_SLIDER1 = wxNewId();
const long TestdcFrame::ID_ANGULARMETER1 = wxNewId();
const long TestdcFrame::ID_STATICTEXT1 = wxNewId();
const long TestdcFrame::ID_STATICTEXT2 = wxNewId();
const long TestdcFrame::ID_LINEARMETER1 = wxNewId();
const long TestdcFrame::ID_STATICTEXT3 = wxNewId();
const long TestdcFrame::ID_LCDDISPLAY1 = wxNewId();
const long TestdcFrame::ID_LCDCLOCK1 = wxNewId();
const long TestdcFrame::ID_STATICTEXT4 = wxNewId();
const long TestdcFrame::ID_STATICTEXT5 = wxNewId();
const long TestdcFrame::ID_BMPSWITCHER1 = wxNewId();
const long TestdcFrame::ID_BUTTON1 = wxNewId();
const long TestdcFrame::ID_STATICTEXT6 = wxNewId();
const long TestdcFrame::ID_STATICTEXT7 = wxNewId();
const long TestdcFrame::ID_LINEARREGULATOR1 = wxNewId();
const long TestdcFrame::ID_LCDDISPLAY2 = wxNewId();
const long TestdcFrame::ID_ANGULARREGULATOR1 = wxNewId();
const long TestdcFrame::ID_LCDDISPLAY3 = wxNewId();
const long TestdcFrame::ID_STATICTEXT8 = wxNewId();
const long TestdcFrame::ID_BMPCHECKBOX1 = wxNewId();
const long TestdcFrame::ID_STATICBITMAP1 = wxNewId();
const long TestdcFrame::ID_STATICTEXT9 = wxNewId();
const long TestdcFrame::ID_PANEL1 = wxNewId();
const long TestdcFrame::idMenuQuit = wxNewId();
const long TestdcFrame::idMenuAbout = wxNewId();
const long TestdcFrame::ID_STATUSBAR1 = wxNewId();
const long TestdcFrame::ID_TB_ABOUT = wxNewId();
const long TestdcFrame::ID_TOOLBAR1 = wxNewId();
//*)

BEGIN_EVENT_TABLE(TestdcFrame,wxFrame)
    //(*EventTable(TestdcFrame)
    //*)
END_EVENT_TABLE()

TestdcFrame::TestdcFrame(wxWindow* parent,wxWindowID id)
{
    //(*Initialize(TestdcFrame)
    wxMenuItem* MenuItem2;
    wxMenuItem* MenuItem1;
    wxMenu* Menu1;
    wxMenuBar* MenuBar1;
    wxMenu* Menu2;

    Create(parent, id, _("Koan Industrial Controls"), wxDefaultPosition, wxDefaultSize, wxDEFAULT_FRAME_STYLE, _T("id"));
    SetClientSize(wxSize(680,540));
    Panel1 = new wxPanel(this, ID_PANEL1, wxPoint(124,368), wxDefaultSize, wxTAB_TRAVERSAL, _T("ID_PANEL1"));
    m_slider = new wxSlider(Panel1, ID_SLIDER1, 75, 0, 151, wxPoint(5,30), wxDefaultSize, wxSL_VERTICAL, wxDefaultValidator, _T("ID_SLIDER1"));
    angularmeter = new kwxAngularMeter(Panel1,ID_ANGULARMETER1,wxPoint(50,30),wxSize(200,200));
    angularmeter->SetNumTick(9);
    angularmeter->SetRange(0, 151);
    angularmeter->SetNumSectors(3);
    angularmeter->SetSectorColor(0, wxColour(255, 255, 255));
    angularmeter->SetSectorColor(1, wxColour(0, 255, 0));
    angularmeter->SetSectorColor(2, wxColour(0, 0, 255));
    angularmeter->DrawCurrent(false);
    wxFont AngularMeterFont_1(8,wxMODERN,wxFONTSTYLE_NORMAL,wxNORMAL,false,wxEmptyString,wxFONTENCODING_DEFAULT);
    angularmeter->SetTxtFont(AngularMeterFont_1);
    angularmeter->SetValue(75);
    StaticText1 = new wxStaticText(Panel1, ID_STATICTEXT1, _("LinearMeter"), wxPoint(278,10), wxDefaultSize, 0, _T("ID_STATICTEXT1"));
    StaticText2 = new wxStaticText(Panel1, ID_STATICTEXT2, _("AngularMeter"), wxPoint(120,10), wxDefaultSize, 0, _T("ID_STATICTEXT2"));
    linearmeter = new kwxLinearMeter(Panel1,ID_LINEARMETER1,wxPoint(280,30),wxSize(50,200));
    linearmeter->SetRangeVal(0, 151);
    linearmeter->SetOrizDirection(false);
    linearmeter->SetActiveBarColour(wxColour(0,0,255));
    linearmeter->SetTagsColour(wxColour(0,255,0));
    linearmeter->AddTag(20);
    linearmeter->AddTag(40);
    linearmeter->AddTag(90);
    wxFont LinearMeterFont_1(8,wxMODERN,wxFONTSTYLE_NORMAL,wxNORMAL,false,wxEmptyString,wxFONTENCODING_DEFAULT);
    linearmeter->SetTxtFont(LinearMeterFont_1);
    linearmeter->SetValue(75);
    StaticText3 = new wxStaticText(Panel1, ID_STATICTEXT3, _("LCDDisplay"), wxPoint(25,230), wxDefaultSize, 0, _T("ID_STATICTEXT3"));
    mLCD = new kwxLCDDisplay(Panel1,wxPoint(25,250),wxSize(150,40));
    mLCD->SetValue(wxT("75"));
    mClock = new kwxLCDClock(Panel1,wxPoint(190,250),wxSize(140,40));
    mClock->SetNumberDigits(8);
    StaticText4 = new wxStaticText(Panel1, ID_STATICTEXT4, _("LCDClock"), wxPoint(190,230), wxDefaultSize, 0, _T("ID_STATICTEXT4"));
    StaticText5 = new wxStaticText(Panel1, ID_STATICTEXT5, _("BmpSwitcher"), wxPoint(113,300), wxDefaultSize, 0, _T("ID_STATICTEXT5"));
    bmpswitcher = new kwxBmpSwitcher(Panel1, ID_BMPSWITCHER1, wxPoint(110,315), wxSize(60,60));
    bmpswitcher->AddBitmap(new wxBitmap(wxImage(wxT("res\\false.xpm"))));
    bmpswitcher->AddBitmap(new wxBitmap(wxImage(wxT("res\\true.xpm"))));
    bmpswitcher->AddBitmap(new wxBitmap(wxImage(wxT("res\\test.xpm"))));
    m_button = new wxButton(Panel1, ID_BUTTON1, _("Toggle Bitmap"), wxPoint(20,330), wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON1"));
    StaticText6 = new wxStaticText(Panel1, ID_STATICTEXT6, _("LinearRegulator"), wxPoint(380,10), wxDefaultSize, 0, _T("ID_STATICTEXT6"));
    StaticText7 = new wxStaticText(Panel1, ID_STATICTEXT7, _("AngularRegulator"), wxPoint(510,27), wxDefaultSize, 0, _T("ID_STATICTEXT7"));
    linearreg = new kwxLinearRegulator(Panel1,ID_LINEARREGULATOR1,wxPoint(390,30),wxSize(50,200), wxBORDER_NONE);
    linearreg->SetOrizDirection(false);
    linearreg->ShowCurrent(false);
    linearreg->AddTag(30);
    linearreg->AddTag(80);
    wxFont LinearRegulatorFont_1(8,wxMODERN,wxFONTSTYLE_NORMAL,wxNORMAL,false,wxEmptyString,wxFONTENCODING_DEFAULT);
    linearreg->SetTxtFont(LinearRegulatorFont_1);
    linearreg->SetValue(10);
    mLinearLCD = new kwxLCDDisplay(Panel1,wxPoint(390,235),wxSize(49,31));
    mLinearLCD->SetNumberDigits(3);
    mLinearLCD->SetValue(wxT("10"));
    angularreg = new kwxAngularRegulator(Panel1,ID_ANGULARREGULATOR1,wxPoint(500,50),wxSize(100,100), wxBORDER_NONE);
    angularreg->SetRange(0, 151);
    angularreg->SetAngle(-45, 215);
    angularreg->SetExtCircleColour(wxColour(82,150,243));
    angularreg->SetIntCircleColour(wxColour(0,0,255));
    angularreg->SetKnobBorderColour(wxColour(192,192,192));
    angularreg->SetKnobColour(wxColour(181,209,246));
    angularreg->SetTagsColour(wxColour(255,255,255));
    angularreg->AddTag(40);
    angularreg->AddTag(100);
    angularreg->SetValue(0);
    mAngularLCD = new kwxLCDDisplay(Panel1,wxPoint(530,160),wxSize(49,31));
    mAngularLCD->SetNumberDigits(3);
    mAngularLCD->SetValue(wxT("0"));
    StaticText8 = new wxStaticText(Panel1, ID_STATICTEXT8, _("BmpCheckBox"), wxPoint(510,220), wxDefaultSize, 0, _T("ID_STATICTEXT8"));
    wxBitmap *pbmpOn = new wxBitmap(wxImage(_T(".\\res\\submit_green.xpm")));
    wxBitmap *pbmpOff = new wxBitmap(wxImage(_T(".\\res\\reset_green.xpm")));
    wxBitmap *pbmpOnSel = new wxBitmap(wxImage(_T(".\\res\\submit_orange.xpm")));
    wxBitmap *pbmpOffSel = new wxBitmap(wxImage(_T(".\\res\\reset_orange.xpm")));
    focusbtn = new kwxBmpCheckBox(Panel1,ID_BMPCHECKBOX1, *pbmpOn, *pbmpOff, *pbmpOnSel, *pbmpOffSel, wxPoint(510,240),wxSize(83,30), wxBORDER_NONE);
    focusbtn->SetBorder(false, 101);
    staticbmp = new wxStaticBitmap(Panel1, ID_STATICBITMAP1, wxBitmap(wxImage(_T(".\\res\\koan200.xpm")).Rescale(wxSize(200,150).GetWidth(),wxSize(200,150).GetHeight())), wxPoint(470,320), wxSize(200,150), 0, _T("ID_STATICBITMAP1"));
    StaticText9 = new wxStaticText(Panel1, ID_STATICTEXT9, _("http://www.koansoftware.com"), wxPoint(5,436), wxDefaultSize, 0, _T("ID_STATICTEXT9"));
    wxFont StaticText9Font(25,wxSWISS,wxFONTSTYLE_NORMAL,wxNORMAL,false,wxEmptyString,wxFONTENCODING_DEFAULT);
    StaticText9->SetFont(StaticText9Font);
    MenuBar1 = new wxMenuBar();
    Menu1 = new wxMenu();
    MenuItem1 = new wxMenuItem(Menu1, idMenuQuit, _("Exit\tAlt-X"), _("Quit this program"), wxITEM_NORMAL);
    Menu1->Append(MenuItem1);
    MenuBar1->Append(Menu1, _("&File"));
    Menu2 = new wxMenu();
    MenuItem2 = new wxMenuItem(Menu2, idMenuAbout, _("About...\tCtrl-A"), _("Show about dialog"), wxITEM_NORMAL);
    Menu2->Append(MenuItem2);
    MenuBar1->Append(Menu2, _("Help"));
    SetMenuBar(MenuBar1);
    StatusBar1 = new wxStatusBar(this, ID_STATUSBAR1, 0, _T("ID_STATUSBAR1"));
    int __wxStatusBarWidths_1[1] = { -1 };
    int __wxStatusBarStyles_1[1] = { wxSB_NORMAL };
    StatusBar1->SetFieldsCount(1,__wxStatusBarWidths_1);
    StatusBar1->SetStatusStyles(1,__wxStatusBarStyles_1);
    SetStatusBar(StatusBar1);
    ToolBar1 = new wxToolBar(this, ID_TOOLBAR1, wxDefaultPosition, wxDefaultSize, wxTB_HORIZONTAL|wxNO_BORDER, _T("ID_TOOLBAR1"));
    ToolBarItem1 = ToolBar1->AddTool(ID_TB_ABOUT, wxEmptyString, wxBitmap(wxImage(_T(".\\res\\help.xpm"))), wxNullBitmap, wxITEM_NORMAL, _("About this program"), wxEmptyString);
    ToolBar1->Realize();
    SetToolBar(ToolBar1);

    Connect(ID_SLIDER1,wxEVT_SCROLL_TOP,(wxObjectEventFunction)&TestdcFrame::Onm_sliderCmdScroll);
    Connect(ID_SLIDER1,wxEVT_SCROLL_BOTTOM,(wxObjectEventFunction)&TestdcFrame::Onm_sliderCmdScroll);
    Connect(ID_SLIDER1,wxEVT_SCROLL_LINEUP,(wxObjectEventFunction)&TestdcFrame::Onm_sliderCmdScroll);
    Connect(ID_SLIDER1,wxEVT_SCROLL_LINEDOWN,(wxObjectEventFunction)&TestdcFrame::Onm_sliderCmdScroll);
    Connect(ID_SLIDER1,wxEVT_SCROLL_PAGEUP,(wxObjectEventFunction)&TestdcFrame::Onm_sliderCmdScroll);
    Connect(ID_SLIDER1,wxEVT_SCROLL_PAGEDOWN,(wxObjectEventFunction)&TestdcFrame::Onm_sliderCmdScroll);
    Connect(ID_SLIDER1,wxEVT_SCROLL_THUMBTRACK,(wxObjectEventFunction)&TestdcFrame::Onm_sliderCmdScroll);
    Connect(ID_SLIDER1,wxEVT_SCROLL_THUMBRELEASE,(wxObjectEventFunction)&TestdcFrame::Onm_sliderCmdScroll);
    Connect(ID_SLIDER1,wxEVT_SCROLL_CHANGED,(wxObjectEventFunction)&TestdcFrame::Onm_sliderCmdScroll);
    Connect(ID_SLIDER1,wxEVT_COMMAND_SLIDER_UPDATED,(wxObjectEventFunction)&TestdcFrame::Onm_sliderCmdScroll);
    Connect(ID_BUTTON1,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&TestdcFrame::Onm_buttonClick);
    Connect(ID_LINEARREGULATOR1,kwxEVT_LINEARREG_CHANGE,(wxObjectEventFunction)&TestdcFrame::OnlinearregChanged);
    Connect(ID_ANGULARREGULATOR1,kwxEVT_ANGREG_CHANGE,(wxObjectEventFunction)&TestdcFrame::OnangularregChanged);
    Connect(ID_BMPCHECKBOX1,kwxEVT_BITBUTTON_CLICK,(wxObjectEventFunction)&TestdcFrame::OnfocusbtnClicked);
    Connect(idMenuQuit,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&TestdcFrame::OnQuit);
    Connect(idMenuAbout,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&TestdcFrame::OnAbout);
    Connect(ID_TB_ABOUT,wxEVT_COMMAND_TOOL_CLICKED,(wxObjectEventFunction)&TestdcFrame::OnAbout);
    //*)

    mClock->StartClock();
}

TestdcFrame::~TestdcFrame()
{
    //(*Destroy(TestdcFrame)
    //*)
}

void TestdcFrame::OnQuit(wxCommandEvent& event)
{
    Close();
}

void TestdcFrame::OnAbout(wxCommandEvent& event)
{
    // called when help - about is picked from the menu or toolbar
    wxString msg;
    msg.Printf(_("About Koan Industrial Controls...\n"));
    wxMessageBox(msg, _("About Koan Industrial Controls"), wxOK | wxICON_INFORMATION, this);}

// EVT_COMMAND_SCROLL should be used rather than pointing all events here individually, but it's broken.
void TestdcFrame::Onm_sliderCmdScroll(wxScrollEvent& event)
{
	int pos = event.GetPosition() ;
	wxString sPos;

	sPos.Printf(wxT("%d"), pos) ;

	angularmeter->SetValue(pos);

	linearmeter->SetValue(pos);
	mLCD->SetValue(sPos) ;
}

void TestdcFrame::Onm_buttonClick(wxCommandEvent& event)
{
	bmpswitcher->IncState() ;
}

void TestdcFrame::OnfocusbtnClicked(wxCommandEvent& event)
{
    wxString msg;
	bool state = focusbtn->GetState() ;

	if(state)
		msg.Printf(_("BmpCheckBox Event\nState Pressed\n"));
	else
		msg.Printf(_("BmpCheckBox Event\nState Not Pressed\n"));

    wxMessageBox(msg,wxT("BmpCheckBox"), wxOK | wxICON_INFORMATION, this);
}

void TestdcFrame::OnlinearregChanged(wxCommandEvent& event)
{
	wxString val ;

	val.Printf(wxT("%d"), linearreg->GetValue()) ;

	mLinearLCD->SetValue(val) ;
}

void TestdcFrame::OnangularregChanged(wxCommandEvent& event)
{
	wxString val ;
	val.Printf(wxT("%d"), angularreg->GetValue()) ;
	mAngularLCD->SetValue(val) ;
}
