/***************************************************************
 * Name:      TestdcApp.cpp
 * Purpose:   Code for Application Class
 * Author:    Gary Harris (garyjharris@sourceforge.net)
 * Created:   2010-04-22
 * Copyright: Gary Harris (http://cryogen.66ghz.com/)
 * License:	KWIC Licence
 **************************************************************/

#include "wx_pch.h"
#include "TestdcApp.h"

//(*AppHeaders
#include "TestdcMain.h"
#include <wx/image.h>
//*)

IMPLEMENT_APP(TestdcApp);

bool TestdcApp::OnInit()
{
    //(*AppInitialize
    bool wxsOK = true;
    wxInitAllImageHandlers();
    if ( wxsOK )
    {
    TestdcFrame* Frame = new TestdcFrame(0);
    Frame->Show();
    SetTopWindow(Frame);
    }
    //*)
    return wxsOK;

}
