/***************************************************************
 * Name:      KWICDemoMain.h
 * Purpose:   Defines Application Frame
 * Author:    Gary Harris (garyjharris@sourceforge.net)
 * Created:   2010-04-22
 * Copyright: Gary Harris (http://cryogen.66ghz.com/)
 * License:	KWIC Licence
 **************************************************************/

#ifndef KWICDEMOMAIN_H
#define KWICDEMOMAIN_H

//(*Headers(KWICDemoFrame)
#include "wx/KWIC/AngularMeter.h"
#include "wx/KWIC/LinearRegulator.h"
#include "wx/KWIC/BmpCheckBox.h"
#include <wx/stattext.h>
#include <wx/menu.h>
#include <wx/panel.h>
#include "wx/KWIC/LinearMeter.h"
#include "wx/KWIC/BmpSwitcher.h"
#include <wx/frame.h>
#include <wx/timer.h>
#include <wx/statusbr.h>
//*)

class KWICDemoFrame: public wxFrame
{
    public:

        KWICDemoFrame(wxWindow* parent,wxWindowID id = -1);
        virtual ~KWICDemoFrame();

    private:

        //(*Handlers(KWICDemoFrame)
        void OnQuit(wxCommandEvent& event);
        void OnAbout(wxCommandEvent& event);
        void OnBmpCheckbox1Clicked(wxCommandEvent& event);
        void OnPanel1Paint(wxPaintEvent& event);
        void OnTimer1Trigger(wxTimerEvent& event);
        //*)

        //(*Identifiers(KWICDemoFrame)
        static const long ID_BMPCHECKBOX1;
        static const long ID_STATICTEXT1;
        static const long ID_ANGULARMETER1;
        static const long ID_ANGULARMETER3;
        static const long ID_ANGULARMETER2;
        static const long ID_LINEARREGULATOR1;
        static const long ID_ANGULARMETER4;
        static const long ID_ANGULARMETER5;
        static const long ID_ANGULARMETER6;
        static const long ID_ANGULARMETER7;
        static const long ID_STATICTEXT2;
        static const long ID_STATICTEXT3;
        static const long ID_STATICTEXT4;
        static const long ID_STATICTEXT5;
        static const long ID_STATICTEXT6;
        static const long ID_STATICTEXT7;
        static const long ID_BMPSWITCHER1;
        static const long ID_STATICTEXT8;
        static const long ID_STATICTEXT9;
        static const long ID_LINEARMETER1;
        static const long ID_LINEARMETER2;
        static const long ID_LINEARMETER3;
        static const long ID_LINEARMETER4;
        static const long ID_LINEARMETER5;
        static const long ID_LINEARMETER6;
        static const long ID_LINEARMETER7;
        static const long ID_LINEARMETER8;
        static const long ID_LINEARMETER9;
        static const long ID_LINEARMETER10;
        static const long ID_STATICTEXT10;
        static const long ID_PANEL1;
        static const long idMenuQuit;
        static const long idMenuAbout;
        static const long ID_STATUSBAR1;
        static const long ID_TIMER1;
        //*)

        //(*Declarations(KWICDemoFrame)
        wxStaticText* StaticText9;
        kwxBmpCheckBox* BmpCheckbox1;
        kwxAngularMeter* AngularMeter4;
        kwxLinearMeter* EQ3;
        kwxLinearMeter* EQ1;
        kwxLinearMeter* EQ8;
        kwxLinearMeter* EQ6;
        wxStaticText* StaticText2;
        wxStaticText* StaticText6;
        kwxLinearMeter* EQ5;
        kwxLinearMeter* EQ7;
        wxStaticText* StaticText8;
        kwxBmpSwitcher* BmpSwitcher1;
        kwxAngularMeter* AngularMeter5;
        wxPanel* Panel1;
        wxStaticText* StaticText1;
        wxStaticText* StaticText3;
        kwxLinearMeter* EQ9;
        kwxLinearMeter* EQ10;
        kwxAngularMeter* AngularMeter1;
        kwxLinearRegulator* LinearRegulator1;
        kwxAngularMeter* AngularMeter6;
        kwxAngularMeter* AngularMeter2;
        wxStaticText* m_txtBmpChk;
        kwxAngularMeter* AngularMeter7;
        wxStaticText* StaticText5;
        wxStaticText* StaticText7;
        wxStatusBar* StatusBar1;
        kwxLinearMeter* EQ4;
        wxStaticText* StaticText4;
        kwxLinearMeter* EQ2;
        wxTimer Timer1;
        kwxAngularMeter* AngularMeter3;
        //*)

        DECLARE_EVENT_TABLE()
};

#endif // KWICDEMOMAIN_H
