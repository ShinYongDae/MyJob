/***************************************************************
 * Name:      KWICDemoMain.cpp
 * Purpose:   Code for Application Frame
 * Author:    Gary Harris (garyjharris@sourceforge.net)
 * Created:   2010-04-22
 * Copyright: Gary Harris (http://cryogen.66ghz.com/)
 * License:	KWIC Licence
 **************************************************************/

#include "wx_pch.h"
#include "KWICDemoMain.h"
#include <wx/msgdlg.h>

//(*InternalHeaders(KWICDemoFrame)
#include <wx/bitmap.h>
#include <wx/font.h>
#include <wx/intl.h>
#include <wx/image.h>
#include <wx/string.h>
//*)

//helper functions
enum wxbuildinfoformat {
    short_f, long_f };

wxString wxbuildinfo(wxbuildinfoformat format)
{
    wxString wxbuild(wxVERSION_STRING);

    if (format == long_f )
    {
#if defined(__WXMSW__)
        wxbuild << _T("-Windows");
#elif defined(__UNIX__)
        wxbuild << _T("-Linux");
#endif

#if wxUSE_UNICODE
        wxbuild << _T("-Unicode build");
#else
        wxbuild << _T("-ANSI build");
#endif // wxUSE_UNICODE
    }

    return wxbuild;
}

//(*IdInit(KWICDemoFrame)
const long KWICDemoFrame::ID_BMPCHECKBOX1 = wxNewId();
const long KWICDemoFrame::ID_STATICTEXT1 = wxNewId();
const long KWICDemoFrame::ID_ANGULARMETER1 = wxNewId();
const long KWICDemoFrame::ID_ANGULARMETER3 = wxNewId();
const long KWICDemoFrame::ID_ANGULARMETER2 = wxNewId();
const long KWICDemoFrame::ID_LINEARREGULATOR1 = wxNewId();
const long KWICDemoFrame::ID_ANGULARMETER4 = wxNewId();
const long KWICDemoFrame::ID_ANGULARMETER5 = wxNewId();
const long KWICDemoFrame::ID_ANGULARMETER6 = wxNewId();
const long KWICDemoFrame::ID_ANGULARMETER7 = wxNewId();
const long KWICDemoFrame::ID_STATICTEXT2 = wxNewId();
const long KWICDemoFrame::ID_STATICTEXT3 = wxNewId();
const long KWICDemoFrame::ID_STATICTEXT4 = wxNewId();
const long KWICDemoFrame::ID_STATICTEXT5 = wxNewId();
const long KWICDemoFrame::ID_STATICTEXT6 = wxNewId();
const long KWICDemoFrame::ID_STATICTEXT7 = wxNewId();
const long KWICDemoFrame::ID_BMPSWITCHER1 = wxNewId();
const long KWICDemoFrame::ID_STATICTEXT8 = wxNewId();
const long KWICDemoFrame::ID_STATICTEXT9 = wxNewId();
const long KWICDemoFrame::ID_LINEARMETER1 = wxNewId();
const long KWICDemoFrame::ID_LINEARMETER2 = wxNewId();
const long KWICDemoFrame::ID_LINEARMETER3 = wxNewId();
const long KWICDemoFrame::ID_LINEARMETER4 = wxNewId();
const long KWICDemoFrame::ID_LINEARMETER5 = wxNewId();
const long KWICDemoFrame::ID_LINEARMETER6 = wxNewId();
const long KWICDemoFrame::ID_LINEARMETER7 = wxNewId();
const long KWICDemoFrame::ID_LINEARMETER8 = wxNewId();
const long KWICDemoFrame::ID_LINEARMETER9 = wxNewId();
const long KWICDemoFrame::ID_LINEARMETER10 = wxNewId();
const long KWICDemoFrame::ID_STATICTEXT10 = wxNewId();
const long KWICDemoFrame::ID_PANEL1 = wxNewId();
const long KWICDemoFrame::idMenuQuit = wxNewId();
const long KWICDemoFrame::idMenuAbout = wxNewId();
const long KWICDemoFrame::ID_STATUSBAR1 = wxNewId();
const long KWICDemoFrame::ID_TIMER1 = wxNewId();
//*)

BEGIN_EVENT_TABLE(KWICDemoFrame,wxFrame)
    //(*EventTable(KWICDemoFrame)
    //*)
END_EVENT_TABLE()

KWICDemoFrame::KWICDemoFrame(wxWindow* parent,wxWindowID id)
{
    //(*Initialize(KWICDemoFrame)
    wxMenuItem* MenuItem2;
    wxMenuItem* MenuItem1;
    wxMenu* Menu1;
    wxMenuBar* MenuBar1;
    wxMenu* Menu2;

    Create(parent, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxDEFAULT_FRAME_STYLE, _T("wxID_ANY"));
    SetClientSize(wxSize(742,450));
    Panel1 = new wxPanel(this, ID_PANEL1, wxPoint(116,268), wxDefaultSize, wxTAB_TRAVERSAL, _T("ID_PANEL1"));
    wxBitmap *pbmpOn = new wxBitmap(wxImage(_T(".\\res\\buton.xpm")));
    wxBitmap *pbmpOff = new wxBitmap(wxImage(_T(".\\res\\but.xpm")));
    wxBitmap *pbmpOnSel = new wxBitmap(wxImage(_T(".\\res\\butpress.xpm")));
    wxBitmap *pbmpOffSel = new wxBitmap(wxImage(_T(".\\res\\butpress.xpm")));
    BmpCheckbox1 = new kwxBmpCheckBox(Panel1,ID_BMPCHECKBOX1, *pbmpOn, *pbmpOff, *pbmpOnSel, *pbmpOffSel, wxPoint(352,252),wxSize(82,68), wxBORDER_NONE);
    m_txtBmpChk = new wxStaticText(Panel1, ID_STATICTEXT1, _("Unchecked"), wxPoint(368,324), wxDefaultSize, 0, _T("ID_STATICTEXT1"));
    AngularMeter1 = new kwxAngularMeter(Panel1,ID_ANGULARMETER1,wxPoint(28,48),wxSize(150,150));
    AngularMeter1->SetNumTick(2);
    AngularMeter1->SetNumSectors(3);
    AngularMeter1->SetSectorColor(0, wxColour(64, 0, 128));
    AngularMeter1->SetSectorColor(1, wxColour(128, 0, 255));
    AngularMeter1->SetSectorColor(2, wxColour(128, 128, 255));
    AngularMeter1->SetNeedleColour(wxColour(255,128,128));
    AngularMeter1->SetBackColour(wxColour(184,219,248));
    AngularMeter1->SetBorderColour(wxColour(0,0,128));
    wxFont AngularMeterFont_1(8,wxSWISS,wxFONTSTYLE_NORMAL,wxNORMAL,false,_T("Lucida Handwriting"),wxFONTENCODING_DEFAULT);
    AngularMeter1->SetTxtFont(AngularMeterFont_1);
    AngularMeter1->SetValue(45);
    AngularMeter3 = new kwxAngularMeter(Panel1,ID_ANGULARMETER3,wxPoint(348,48),wxSize(80,76));
    AngularMeter3->SetNumSectors(8);
    AngularMeter3->SetSectorColor(0, wxColour(254, 252, 214));
    AngularMeter3->SetSectorColor(1, wxColour(255, 255, 198));
    AngularMeter3->SetSectorColor(2, wxColour(238, 242, 157));
    AngularMeter3->SetSectorColor(3, wxColour(242, 245, 137));
    AngularMeter3->SetSectorColor(4, wxColour(240, 233, 134));
    AngularMeter3->SetSectorColor(5, wxColour(255, 255, 0));
    AngularMeter3->SetSectorColor(6, wxColour(225, 233, 86));
    AngularMeter3->SetSectorColor(7, wxColour(233, 221, 7));
    AngularMeter3->DrawCurrent(false);
    AngularMeter3->SetValue(78);
    AngularMeter2 = new kwxAngularMeter(Panel1,ID_ANGULARMETER2,wxPoint(212,48),wxSize(100,100));
    AngularMeter2->SetNumTick(4);
    AngularMeter2->SetRange(0, 204);
    AngularMeter2->SetNumSectors(5);
    AngularMeter2->SetSectorColor(0, wxColour(0, 128, 0));
    AngularMeter2->SetSectorColor(1, wxColour(0, 128, 0));
    AngularMeter2->SetSectorColor(2, wxColour(0, 128, 0));
    AngularMeter2->SetSectorColor(3, wxColour(0, 128, 0));
    AngularMeter2->SetSectorColor(4, wxColour(255, 0, 0));
    AngularMeter2->SetNeedleColour(wxColour(255,128,0));
    AngularMeter2->SetValue(100);
    LinearRegulator1 = new kwxLinearRegulator(Panel1,ID_LINEARREGULATOR1,wxPoint(632,48),wxSize(68,204), wxBORDER_NONE);
    LinearRegulator1->SetOrizDirection(false);
    LinearRegulator1->ShowCurrent(false);
    LinearRegulator1->SetActiveBarColour(wxColour(227,145,213));
    LinearRegulator1->SetPassiveBarColour(wxColour(176,0,176));
    LinearRegulator1->SetBorderColour(wxColour(128,0,255));
    LinearRegulator1->SetTxtLimitColour(wxColour(128,0,64));
    LinearRegulator1->SetTagsColour(wxColour(82,39,74));
    LinearRegulator1->AddTag(25);
    LinearRegulator1->AddTag(50);
    LinearRegulator1->AddTag(75);
    LinearRegulator1->SetValue(75);
    AngularMeter4 = new kwxAngularMeter(Panel1,ID_ANGULARMETER4,wxPoint(464,48),wxSize(100,100));
    AngularMeter4->SetNumTick(8);
    AngularMeter4->SetRange(0, 9);
    AngularMeter4->SetAngle(30, 150);
    AngularMeter4->SetSectorColor(0, wxColour(0, 128, 128));
    AngularMeter4->DrawCurrent(false);
    AngularMeter4->SetNeedleColour(wxColour(255,0,0));
    AngularMeter4->SetValue(3);
    AngularMeter4->Disable();
    AngularMeter5 = new kwxAngularMeter(Panel1,ID_ANGULARMETER5,wxPoint(44,252),wxSize(60,60));
    AngularMeter5->SetRange(0, 10);
    AngularMeter5->SetAngle(-90, 270);
    AngularMeter5->SetSectorColor(0, wxColour(255, 255, 255));
    AngularMeter5->SetBackColour(wxColour(128,128,128));
    AngularMeter5->SetBorderColour(wxColour(128,128,128));
    AngularMeter6 = new kwxAngularMeter(Panel1,ID_ANGULARMETER6,wxPoint(104,252),wxSize(60,60));
    AngularMeter6->SetRange(0, 10);
    AngularMeter6->SetAngle(-90, 270);
    AngularMeter6->SetSectorColor(0, wxColour(255, 255, 255));
    AngularMeter6->SetBackColour(wxColour(128,128,128));
    AngularMeter6->SetBorderColour(wxColour(128,128,128));
    AngularMeter7 = new kwxAngularMeter(Panel1,ID_ANGULARMETER7,wxPoint(164,252),wxSize(60,60));
    AngularMeter7->SetRange(0, 10);
    AngularMeter7->SetAngle(-90, 270);
    AngularMeter7->SetSectorColor(0, wxColour(255, 255, 255));
    AngularMeter7->SetBackColour(wxColour(128,128,128));
    AngularMeter7->SetBorderColour(wxColour(128,128,128));
    StaticText1 = new wxStaticText(Panel1, ID_STATICTEXT2, _("Odometer Style"), wxPoint(100,228), wxDefaultSize, 0, _T("ID_STATICTEXT2"));
    StaticText2 = new wxStaticText(Panel1, ID_STATICTEXT3, _("Tachometer Style"), wxPoint(220,20), wxDefaultSize, 0, _T("ID_STATICTEXT3"));
    StaticText3 = new wxStaticText(Panel1, ID_STATICTEXT4, _("Graduated"), wxPoint(360,20), wxDefaultSize, 0, _T("ID_STATICTEXT4"));
    StaticText4 = new wxStaticText(Panel1, ID_STATICTEXT5, _("VDU Style"), wxPoint(492,20), wxDefaultSize, 0, _T("ID_STATICTEXT5"));
    StaticText5 = new wxStaticText(Panel1, ID_STATICTEXT6, _("Coloured"), wxPoint(80,20), wxDefaultSize, 0, _T("ID_STATICTEXT6"));
    StaticText6 = new wxStaticText(Panel1, ID_STATICTEXT7, _("Coloured"), wxPoint(642,20), wxDefaultSize, 0, _T("ID_STATICTEXT7"));
    BmpSwitcher1 = new kwxBmpSwitcher(Panel1, ID_BMPSWITCHER1, wxPoint(260,264), wxSize(32,32));
    BmpSwitcher1->AddBitmap(new wxBitmap(wxImage(wxT("res\\ohsmile.xpm"))));
    BmpSwitcher1->AddBitmap(new wxBitmap(wxImage(wxT("res\\sadsmile.xpm"))));
    BmpSwitcher1->AddBitmap(new wxBitmap(wxImage(wxT("res\\smile.xpm"))));
    StaticText7 = new wxStaticText(Panel1, ID_STATICTEXT8, _("Bmp Switcher"), wxPoint(248,228), wxDefaultSize, 0, _T("ID_STATICTEXT8"));
    StaticText8 = new wxStaticText(Panel1, ID_STATICTEXT9, _("Bmp Checkbox"), wxPoint(355,228), wxDefaultSize, 0, _T("ID_STATICTEXT9"));
    EQ1 = new kwxLinearMeter(Panel1,ID_LINEARMETER1,wxPoint(470,252),wxSize(5,100));
    EQ1->SetRangeVal(0, 10);
    EQ1->SetOrizDirection(false);
    EQ1->ShowCurrent(false);
    EQ1->ShowLimits(false);
    EQ2 = new kwxLinearMeter(Panel1,ID_LINEARMETER2,wxPoint(476,252),wxSize(5,100));
    EQ2->SetRangeVal(0, 10);
    EQ2->SetOrizDirection(false);
    EQ2->ShowCurrent(false);
    EQ2->ShowLimits(false);
    EQ3 = new kwxLinearMeter(Panel1,ID_LINEARMETER3,wxPoint(482,252),wxSize(5,100));
    EQ3->SetRangeVal(0, 10);
    EQ3->SetOrizDirection(false);
    EQ3->ShowCurrent(false);
    EQ3->ShowLimits(false);
    EQ4 = new kwxLinearMeter(Panel1,ID_LINEARMETER4,wxPoint(488,252),wxSize(5,100));
    EQ4->SetRangeVal(0, 10);
    EQ4->SetOrizDirection(false);
    EQ4->ShowCurrent(false);
    EQ4->ShowLimits(false);
    EQ5 = new kwxLinearMeter(Panel1,ID_LINEARMETER5,wxPoint(494,252),wxSize(5,100));
    EQ5->SetRangeVal(0, 10);
    EQ5->SetOrizDirection(false);
    EQ5->ShowCurrent(false);
    EQ5->ShowLimits(false);
    EQ6 = new kwxLinearMeter(Panel1,ID_LINEARMETER6,wxPoint(500,252),wxSize(5,100));
    EQ6->SetRangeVal(0, 10);
    EQ6->SetOrizDirection(false);
    EQ6->ShowCurrent(false);
    EQ6->ShowLimits(false);
    EQ7 = new kwxLinearMeter(Panel1,ID_LINEARMETER7,wxPoint(506,252),wxSize(5,100));
    EQ7->SetRangeVal(0, 10);
    EQ7->SetOrizDirection(false);
    EQ7->ShowCurrent(false);
    EQ7->ShowLimits(false);
    EQ8 = new kwxLinearMeter(Panel1,ID_LINEARMETER8,wxPoint(512,252),wxSize(5,100));
    EQ8->SetRangeVal(0, 10);
    EQ8->SetOrizDirection(false);
    EQ8->ShowCurrent(false);
    EQ8->ShowLimits(false);
    EQ9 = new kwxLinearMeter(Panel1,ID_LINEARMETER9,wxPoint(518,252),wxSize(5,100));
    EQ9->SetRangeVal(0, 10);
    EQ9->SetOrizDirection(false);
    EQ9->ShowCurrent(false);
    EQ9->ShowLimits(false);
    EQ10 = new kwxLinearMeter(Panel1,ID_LINEARMETER10,wxPoint(524,252),wxSize(5,100));
    EQ10->SetRangeVal(0, 10);
    EQ10->SetOrizDirection(false);
    EQ10->ShowCurrent(false);
    EQ10->ShowLimits(false);
    StaticText9 = new wxStaticText(Panel1, ID_STATICTEXT10, _("Equalizer"), wxPoint(475,228), wxDefaultSize, 0, _T("ID_STATICTEXT10"));
    MenuBar1 = new wxMenuBar();
    Menu1 = new wxMenu();
    MenuItem1 = new wxMenuItem(Menu1, idMenuQuit, _("Quit\tAlt-F4"), _("Quit the application"), wxITEM_NORMAL);
    Menu1->Append(MenuItem1);
    MenuBar1->Append(Menu1, _("&File"));
    Menu2 = new wxMenu();
    MenuItem2 = new wxMenuItem(Menu2, idMenuAbout, _("About\tF1"), _("Show info about this application"), wxITEM_NORMAL);
    Menu2->Append(MenuItem2);
    MenuBar1->Append(Menu2, _("Help"));
    SetMenuBar(MenuBar1);
    StatusBar1 = new wxStatusBar(this, ID_STATUSBAR1, 0, _T("ID_STATUSBAR1"));
    int __wxStatusBarWidths_1[1] = { -1 };
    int __wxStatusBarStyles_1[1] = { wxSB_NORMAL };
    StatusBar1->SetFieldsCount(1,__wxStatusBarWidths_1);
    StatusBar1->SetStatusStyles(1,__wxStatusBarStyles_1);
    SetStatusBar(StatusBar1);
    Timer1.SetOwner(this, ID_TIMER1);
    Timer1.Start(100, false);

    Connect(ID_BMPCHECKBOX1,kwxEVT_BITBUTTON_CLICK,(wxObjectEventFunction)&KWICDemoFrame::OnBmpCheckbox1Clicked);
    Connect(idMenuQuit,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&KWICDemoFrame::OnQuit);
    Connect(idMenuAbout,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&KWICDemoFrame::OnAbout);
    Connect(ID_TIMER1,wxEVT_TIMER,(wxObjectEventFunction)&KWICDemoFrame::OnTimer1Trigger);
    //*)

    Timer1.Start();
}

KWICDemoFrame::~KWICDemoFrame()
{
    //(*Destroy(KWICDemoFrame)
    //*)
}

void KWICDemoFrame::OnQuit(wxCommandEvent& event)
{
    Close();
}

void KWICDemoFrame::OnAbout(wxCommandEvent& event)
{
    wxString msg = wxbuildinfo(long_f);
    wxMessageBox(msg, _("Welcome to..."));
}

void KWICDemoFrame::OnBmpCheckbox1Clicked(wxCommandEvent& event)
{
	if(BmpCheckbox1->GetState()){
		m_txtBmpChk->SetLabel(wxT("Checked"));
	}
	else{
		m_txtBmpChk->SetLabel(wxT("Unchecked"));
	}
}

int x = 0, y = 0, z = 0;
void KWICDemoFrame::OnTimer1Trigger(wxTimerEvent& event)
{
	x++;
	if(x > 9){
		x = 0;
		y++;
		BmpSwitcher1->IncState();
	}
	if(y > 9){
		y = 0;
		z++;
	}
	if(z > 9){
		z = 0;
	}
	AngularMeter7->SetValue(x);
	AngularMeter6->SetValue(y);
	AngularMeter5->SetValue(z);

	int a, b, c, d, e, f, g, h, i, j;
	a = rand()%10 + 1;
	if(a > 9){
		EQ1->SetActiveBarColour(*wxRED);
	}
	else{
		EQ1->SetActiveBarColour(*wxGREEN);
	}
	EQ1->SetValue(a);
	b = rand()%10 + 1;
	if(b > 9){
		EQ2->SetActiveBarColour(*wxRED);
	}
	else{
		EQ2->SetActiveBarColour(*wxGREEN);
	}
	EQ2->SetValue(b);
	c = rand()%10 + 1;
	if(c > 9){
		EQ3->SetActiveBarColour(*wxRED);
	}
	else{
		EQ3->SetActiveBarColour(*wxGREEN);
	}
	EQ3->SetValue(c);
	d = rand()%10 + 1;
	if(d > 9){
		EQ4->SetActiveBarColour(*wxRED);
	}
	else{
		EQ4->SetActiveBarColour(*wxGREEN);
	}
	EQ4->SetValue(d);
	e = rand()%10 + 1;
	if(e > 9){
		EQ5->SetActiveBarColour(*wxRED);
	}
	else{
		EQ5->SetActiveBarColour(*wxGREEN);
	}
	EQ5->SetValue(e);
	f = rand()%10 + 1;
	if(f > 9){
		EQ6->SetActiveBarColour(*wxRED);
	}
	else{
		EQ6->SetActiveBarColour(*wxGREEN);
	}
	EQ6->SetValue(f);
	g = rand()%10 + 1;
	if(g > 9){
		EQ7->SetActiveBarColour(*wxRED);
	}
	else{
		EQ7->SetActiveBarColour(*wxGREEN);
	}
	EQ7->SetValue(g);
	a = rand()%10 + 1;
	if(h > 9){
		EQ8->SetActiveBarColour(*wxRED);
	}
	else{
		EQ8->SetActiveBarColour(*wxGREEN);
	}
	EQ8->SetValue(h);
	i = rand()%10 + 1;
	if(i > 9){
		EQ9->SetActiveBarColour(*wxRED);
	}
	else{
		EQ9->SetActiveBarColour(*wxGREEN);
	}
	EQ9->SetValue(i);
	j = rand()%10 + 1;
	if(j > 9){
		EQ10->SetActiveBarColour(*wxRED);
	}
	else{
		EQ10->SetActiveBarColour(*wxGREEN);
	}
	EQ10->SetValue(j);
}
