/***************************************************************
 * Name:      KWICDemoApp.cpp
 * Purpose:   Code for Application Class
 * Author:    Gary Harris (garyjharris@sourceforge.net)
 * Created:   2010-04-22
 * Copyright: Gary Harris (http://cryogen.66ghz.com/)
 * License:	KWIC Licence
 **************************************************************/

#include "wx_pch.h"
#include "KWICDemoApp.h"

//(*AppHeaders
#include "KWICDemoMain.h"
#include <wx/image.h>
//*)

IMPLEMENT_APP(KWICDemoApp);

bool KWICDemoApp::OnInit()
{
    //(*AppInitialize
    bool wxsOK = true;
    wxInitAllImageHandlers();
    if ( wxsOK )
    {
    KWICDemoFrame* Frame = new KWICDemoFrame(0);
    Frame->Show();
    SetTopWindow(Frame);
    }
    //*)
    return wxsOK;

}
