/***************************************************************
 * Name:      TestdcMain.h
 * Purpose:   Defines Application Frame
 * Author:    Gary Harris (garyjharris@sourceforge.net)
 * Created:   2010-04-22
 * Copyright: Gary Harris (http://cryogen.66ghz.com/)
 * License:	KWIC Licence
 **************************************************************/

#ifndef TESTDCMAIN_H
#define TESTDCMAIN_H

//(*Headers(TestdcFrame)
#include "wx/KWIC/AngularMeter.h"
#include "wx/KWIC/LinearRegulator.h"
#include "wx/KWIC/BmpCheckBox.h"
#include "wx/KWIC/AngularRegulator.h"
#include <wx/stattext.h>
#include <wx/menu.h>
#include <wx/toolbar.h>
#include "wx/KWIC/LCDWindow.h"
#include <wx/slider.h>
#include <wx/panel.h>
#include "wx/KWIC/LinearMeter.h"
#include <wx/statbmp.h>
#include "wx/KWIC/LCDClock.h"
#include <wx/button.h>
#include "wx/KWIC/BmpSwitcher.h"
#include <wx/frame.h>
#include <wx/statusbr.h>
//*)

class TestdcFrame: public wxFrame
{
    public:

        TestdcFrame(wxWindow* parent,wxWindowID id = -1);
        virtual ~TestdcFrame();

    private:

        //(*Handlers(TestdcFrame)
        void OnQuit(wxCommandEvent& event);
        void OnAbout(wxCommandEvent& event);
        void Onm_sliderCmdScroll(wxScrollEvent& event);
        void Onm_buttonClick(wxCommandEvent& event);
        void OnfocusbtnClicked(wxCommandEvent& event);
        void OnlinearregChanged(wxCommandEvent& event);
        void OnangularregChanged(wxCommandEvent& event);
        //*)

        //(*Identifiers(TestdcFrame)
        static const long ID_SLIDER1;
        static const long ID_ANGULARMETER1;
        static const long ID_STATICTEXT1;
        static const long ID_STATICTEXT2;
        static const long ID_LINEARMETER1;
        static const long ID_STATICTEXT3;
        static const long ID_LCDDISPLAY1;
        static const long ID_LCDCLOCK1;
        static const long ID_STATICTEXT4;
        static const long ID_STATICTEXT5;
        static const long ID_BMPSWITCHER1;
        static const long ID_BUTTON1;
        static const long ID_STATICTEXT6;
        static const long ID_STATICTEXT7;
        static const long ID_LINEARREGULATOR1;
        static const long ID_LCDDISPLAY2;
        static const long ID_ANGULARREGULATOR1;
        static const long ID_LCDDISPLAY3;
        static const long ID_STATICTEXT8;
        static const long ID_BMPCHECKBOX1;
        static const long ID_STATICBITMAP1;
        static const long ID_STATICTEXT9;
        static const long ID_PANEL1;
        static const long idMenuQuit;
        static const long idMenuAbout;
        static const long ID_STATUSBAR1;
        static const long ID_TB_ABOUT;
        static const long ID_TOOLBAR1;
        //*)

        //(*Declarations(TestdcFrame)
        wxStaticText* StaticText9;
        wxToolBar* ToolBar1;
        kwxLCDDisplay* mAngularLCD;
        kwxLCDDisplay* mLCD;
        wxButton* m_button;
        wxSlider* m_slider;
        wxStaticText* StaticText2;
        wxStaticText* StaticText6;
        kwxAngularMeter* angularmeter;
        kwxLinearRegulator* linearreg;
        wxStaticText* StaticText8;
        wxPanel* Panel1;
        wxStaticText* StaticText1;
        wxStaticText* StaticText3;
        wxToolBarToolBase* ToolBarItem1;
        kwxLCDClock* mClock;
        wxStaticText* StaticText5;
        wxStaticText* StaticText7;
        kwxBmpCheckBox* focusbtn;
        wxStatusBar* StatusBar1;
        wxStaticBitmap* staticbmp;
        kwxAngularRegulator* angularreg;
        wxStaticText* StaticText4;
        kwxLCDDisplay* mLinearLCD;
        kwxBmpSwitcher* bmpswitcher;
        kwxLinearMeter* linearmeter;
        //*)

        DECLARE_EVENT_TABLE()
};

#endif // TESTDCMAIN_H
