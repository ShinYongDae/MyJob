/***************************************************************
 * Name:      TestdcApp.h
 * Purpose:   Defines Application Class
 * Author:    Gary Harris (garyjharris@sourceforge.net)
 * Created:   2010-04-22
 * Copyright: Gary Harris (http://cryogen.66ghz.com/)
 * License:	KWIC Licence
 **************************************************************/

#ifndef TESTDCAPP_H
#define TESTDCAPP_H

#include <wx/app.h>

class TestdcApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // TESTDCAPP_H
