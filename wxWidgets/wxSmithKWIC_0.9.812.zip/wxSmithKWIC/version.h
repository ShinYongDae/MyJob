#ifndef VERSION_H
#define VERSION_H

namespace AutoVersion{
	
	//Date Version Types
	static const char DATE[] = "25";
	static const char MONTH[] = "04";
	static const char YEAR[] = "2010";
	static const char UBUNTU_VERSION_STYLE[] = "10.04";
	
	//Software Status
	static const char STATUS[] = "Alpha";
	static const char STATUS_SHORT[] = "a";
	
	//Standard Version Type
	static const long MAJOR = 0;
	static const long MINOR = 9;
	static const long BUILD = 812;
	static const long REVISION = 4394;
	
	//Miscellaneous Version Types
	static const long BUILDS_COUNT = 1460;
	#define RC_FILEVERSION 0,9,812,4394
	#define RC_FILEVERSION_STRING "0, 9, 812, 4394\0"
	static const char FULLVERSION_STRING[] = "0.9.812.4394";
	
	//These values are to keep track of your versioning state, don't modify them.
	static const long BUILD_HISTORY = 12;
	

}
#endif //VERSION_H
