'''
from matplotlib.pylab import *
from numpy import *
t =linspace(0, 3*pi, 31) # 11 -> 21, 31
x = sin(t)
title("Example of plot(t,x): 11-points")
#plot(t,x)
stem(t,x)
show()
'''

import numpy as np
import matplotlib.pyplot as plt

'''
def f(x):
    return x**3-2*x-5
'''

'''
x= np.linspace(-10,10, 256, endpoint=True)
y=f(x)
plt.xlabel('x')
plt.ylabel('f(x)')
plt.axhline(linewidth=1,color = 'black')
plt.axvline(linewidth=1,color = 'black')
plt.plot(x,y)
plt.show()
'''
def f(x):
    return x**3-2*x

x = np.linspace(-3,3, 256, endpoint=True)
y=f(x)
plt.xlabel('x')
plt.ylabel('f(x)')
plt.axhline(linewidth=1,color = 'black')
plt.axvline(linewidth=1,color = 'black')
plt.plot(x,y)
plt.show()

