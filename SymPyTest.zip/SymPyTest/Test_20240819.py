'''
SymPy uses Matplotlib library as a backend to render 2-D and 3-D plots of mathematical functions.
Install the same using following command −
pip3 install matplotlib

plot − 2D line plots

plot3d − 3D line plots

plot_parametric − 2D parametric plots

plot3d_parametric − 3D parametric plots


line_color − specifies color of the plot line.

title − a string to be displayed as title

xlabel − a string to be displayed as label for X axis

ylabel − a string to be displayed as label for y axis

'''



'''
from sympy import *

x = symbols('x')
fx = x**2
#plot(fx, x**3)
#p1 = plot(fx, line_color='g', show=False)
#p2 = plot(x**3, line_color='r', show=False)
#p1.append(p2[0]) #p2와 합치기
#p1.show()
#p1 = plot(fx, x**3, show=False)
#p1[0].line_color = 'g'
#p1.show()
#plot(fx, (x, -5, 5))
#plot(fx, xlim=(-5,5), ylim=(0,25))

#삼각함수 그래프
#plot_parametric((cos(x),sin(x)),(x,-5,5))
#plot_parametric((x, sin(x)))
#plot_parametric((sin(x),x))

ex1 = (x, cos(2*pi*x)/2)
ex2 = (x, sin(2*pi*x)/2)
p = plot_parametric(ex1, ex2, (x, 0, 1), line_color='red', show=False)
p[0].line_color = 'b'
p.show()
'''

'''
from sympy.plotting import plot3d
import sympy as sy
x, y = sy.symbols('x y')
plot3d(x*y**2, (x, -5, 5), (y, -5, 5))
'''

'''
from sympy.plotting import plot3d_parametric_line
import sympy as sy
x, y = sy.symbols('x y')
plot3d_parametric_line(sy.cos(x), sy.sin(x), x, (x, -5, 5))
'''

'''
from sympy import *
import matplotlib.pyplot as mpl
import os

#os.system('clear')
os.system('cls')

t = symbols('t')
x = 0.05*t + 0.2/((t - 5)**2 + 2)
#plot(x)

nums = []
for i in range(1000):
    nums.append(t)
    t += 0.02

plotted = [x for t in nums]

#print(plotted)
#mpl.plot(plotted)
#mpl.ylabel("Speed")
#mpl.show()

plot(plotted, ylabel="Speed")
'''

'''
from sympy import symbols
from numpy import linspace
from sympy import lambdify
import matplotlib.pyplot as mpl

t = symbols('t')
x = 0.05*t + 0.2/((t - 5)**2 + 2)
lam_x = lambdify(t, x, modules=['numpy'])

x_vals = linspace(0, 10, 100)
y_vals = lam_x(x_vals)

mpl.plot(x_vals, y_vals)
mpl.ylabel("Speed")
mpl.show()
'''


'''
from sympy import symbols
from sympy import plot

t = symbols('t')
x = 0.05*t + 0.2/((t - 5)**2 + 2)

plot(x, (t, 0, 10), ylabel='Speed')

'''

'''
from sympy import symbols
from sympy.plotting import plot as symplot

t = symbols('t')
x = 0.05*t + 0.2/((t - 5)**2 + 2)
symplot(x)
'''





