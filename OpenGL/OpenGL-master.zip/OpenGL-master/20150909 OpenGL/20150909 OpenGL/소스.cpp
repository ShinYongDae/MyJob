#include <stdio.h>

void operatior_one(int, int);
void operatior_two(int, int, char);
void operatior_three(int, int, int);

int main(){
	while (1){


	}
}


void operatior_one(int op1, int op){

}
void operatior_two(int op1, int op2, char op){

}
void operatior_three(int op1, int op2, int op3){

}